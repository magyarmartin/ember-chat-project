QUnit.module('JSHint - .');
QUnit.test('router.js should pass jshint', function(assert) { 
  assert.ok(true, 'router.js should pass jshint.'); 
});
