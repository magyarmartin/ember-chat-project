/* jshint ignore:start */

window.EmberENV = {"FEATURES":{}};
var runningTests = false;



/* jshint ignore:end */
